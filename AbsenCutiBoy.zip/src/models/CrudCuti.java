/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import javax.swing.JOptionPane;
import settings.DBConnection;
/**
 *
 * @author lukmanul
 */
public class CrudCuti {
       
   //deklarasi nama method untuk menyimpan data
    public void saveDataPengajuanCuti(  int id_relasi, 
                                        int kode_cuti,
                                        String tanggal_cuti,
                                        String tanggal_cuti_selesai,
                                        String keterangan, 
                                        int nik_pengganti,
                                        String status) {
        
        //buat objek Connection dari class DBConnection() lalu panggil method connect()
        java.sql.Connection conn = new DBConnection().connect();
        
        //try pertama digunakan untuk menyiapkan statement SQL
        try {
            
            //siapkan query sql tanpa nilai (diganti simbol ? 
            String sql="INSERT INTO pengajuan ("
                                                + "id_relasi,"
                                                + "kode_cuti,"
                                                + "tanggal_cuti,"
                                                + "tanggal_cuti_selesai,"
                                                + "keterangan,"
                                                + "nik_pengganti,"
                                                + "status) VALUES (?,?,?,?,?,?,?)";
            
            //query sql di atas, di masukkan kedalam statement
            java.sql.PreparedStatement stmt = conn.prepareStatement (sql);
            
            //try kedua digunakan untuk eksekusi query
            try {
                
                //mengganti (binding) value dari inputan ke statement query
                stmt.setInt(1, id_relasi);
                stmt.setInt(2, kode_cuti);
                stmt.setString(3, tanggal_cuti);
                stmt.setString(4, tanggal_cuti_selesai);
                stmt.setString(5, keterangan);
                stmt.setInt(6, nik_pengganti);
                stmt.setString(7, status);
                               
                
                //lakukan eksekusi query yang sudah lengkap
                stmt.executeUpdate();
                
            //error handling
            } catch(java.sql.SQLException se) {
                System.out.println("Gagal disimpan");
                JOptionPane.showMessageDialog (null,se.getMessage());
            }
            
            //tampilkan pesan sukses, jika data berhasil disimpan ke database
            JOptionPane.showMessageDialog(null,"Data berhasil disimpan!");
            //akhiri statement query
            stmt.close();
            
        //error handling
        } catch (Exception e) {
            
        }
    }
   
}