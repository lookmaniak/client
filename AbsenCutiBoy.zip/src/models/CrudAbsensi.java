/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package models;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import settings.DBConnection;
import javax.swing.JOptionPane;
import java.io.IOException;
/**
 *
 * @author lukmanul
 */
public class CrudAbsensi {
       
   //deklarasi nama method untuk menyimpan data
    public void saveDataIzin(           String nik,
                                        int jenis,
                                        String tanggal,
                                        String alasan,
                                        String status) {
        
        //buat objek Connection dari class DBConnection() lalu panggil method connect()
        java.sql.Connection conn = new DBConnection().connect();
        
        //try pertama digunakan untuk menyiapkan statement SQL
        try {
            
            //siapkan query sql tanpa nilai (diganti simbol ? 
            String sql="INSERT INTO izin ("
                                                + "nik,"
                                                + "jenis_izin,"
                                                + "tanggal,"
                                                + "alasan,"
                                                + "status) VALUES (?,?,?,?,?)";
            
            //query sql di atas, di masukkan kedalam statement
            java.sql.PreparedStatement stmt = conn.prepareStatement (sql);
            
            //try kedua digunakan untuk eksekusi query
            try {
                
                //mengganti (binding) value dari inputan ke statement query
                stmt.setString(1, nik);
                stmt.setInt(2, jenis);
                stmt.setString(3, tanggal);
                stmt.setString(4, alasan);
                stmt.setString(5, status);
                
                //lakukan eksekusi query yang sudah lengkap
                stmt.executeUpdate();
                
            //error handling
            } catch(SQLException se) {
                System.out.println("Gagal disimpan");
                JOptionPane.showMessageDialog (null,se.getMessage());
            }
            
            //tampilkan pesan sukses, jika data berhasil disimpan ke database
            JOptionPane.showMessageDialog(null,"Data berhasil disimpan!");
            //akhiri statement query
            stmt.close();
            
        //error handling
        } catch (Exception e) {
            
        }
    }
   
}