
package Main;

//<editor-fold defaultstate="collapsed" desc="Import">
import forms.LoginForm;
//</editor-fold>

/**
 *
 * @author Zazuli
 */
public class Run {
    
//<editor-fold defaultstate="collapsed" desc="Main Method">
    public static void main(String[] args) {
        LoginForm app = new LoginForm();
        app.setVisible(true);
    }
    
//</editor-fold>
  
}
