package settings;


import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

/**
 *
 * @author Agus Sumarna
 */
public class Center {
     public void makeCenter(JFrame form,boolean autoCenterActivated) {
         if (autoCenterActivated == true) {
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (dim.width - form.getSize().width)/2;
        int y = (dim.height - form.getSize().height)/2;
        form.setLocation(x,y);
         }
    }

}

