/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package settings;

/**
 *
 * @author lukmanul
 */
public class SessionManager {
static int nik,idRelasi,nikAtasan;
static String level,nama,bagian;
    
    public void setNik(int niks) {
        nik = niks;
    }

    public int getActiveNik() {
        return nik;
    }
    
    public void setLevel(String lv) {
        level = lv;
    }
    
    public String getLevelUser() {
        return level;
    }
    
    public void setNama(String nama) {
        SessionManager.nama = nama;
    }
    
    public String getNama() {
        return SessionManager.nama;
    }
    
    public void setBagian(String bagian) {
        SessionManager.bagian = bagian;
    }
    
    public String getBagian() {
        return SessionManager.bagian;
    }
    
    public void setIdRelasi(int id) {
        SessionManager.idRelasi = id;
    }
    
    public int getIdRelasi() {
        return SessionManager.idRelasi;
    }
    
    public void setNikAtasan(int nik) {
        SessionManager.nikAtasan = nik;
    }
    
    public int getNikAtasan() {
        return SessionManager.nikAtasan;
    }
    
    public void clearSession() {
        nik = 0;
        idRelasi = 0;
        level = "";
        nama = "";
        bagian = "";
    }
    
}
